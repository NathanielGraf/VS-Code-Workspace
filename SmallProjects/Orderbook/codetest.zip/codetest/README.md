Hello! Here is my submission, hopefully everything works properly and I understood the instructions as intended. 

To run the code, simply go into orderbook.ipynb, change input_filename to whichever day you want to run, and then run both cells, and it will make an output csv for the data, please let me know if there are any problems or questions with the code. 

Thank you!